# SHAIDAN - APK Reverse Engineering + Mod Suite

"Reverse. Modify. Conquer."

SHAIDAN is a comprehensive all-in-one Termux-based toolkit for APK reverse engineering and mod APK creation. It is designed to provide a powerful and user-friendly environment for security researchers, developers, and enthusiasts to analyze, modify, and test Android applications.

## Features

### Reverse Engineering Modules

*   **Decompiler Suite:** Decompile APKs into Smali, Java (via Jadx, dex2jar, jd-cli, CFR/Procyon/Fernflower), extract native libraries, assets, and decode manifest/resources.
*   **Native Reverse Engineering:** Analyze `.so` files using readelf, objdump, strings, and nm. Detect obfuscation and identify JNI functions.
*   **Smali Reverse Engineering:** Smali syntax highlighting, class/method/field browser, control flow analyzer, search capabilities, and Smali to Java pseudo-code conversion.
*   **DEX Deep Analysis:** DEX header parser, class hierarchy mapper, method call graph generator, string table extractor, multi-DEX support, and detection of dynamic loading/reflection.
*   **Secrets & Pattern Scanner:** Scan for hardcoded API keys, tokens, passwords, database connection strings, endpoint URLs, and encryption keys.
*   **Manifest Analyzer:** Full manifest parser, intent filter analysis, exported component detection, permission protection level checker, and deeplink/URL scheme extraction.
*   **Obfuscation Detector:** Detect ProGuard/R8/DexGuard, string encryption, control flow obfuscation, anti-tamper, root detection, and anti-debugging techniques.
*   **Malware Scanner:** YARA rule scanner, VirusTotal hash lookup, known malware signature database, C2 server communication detection, and SMS/Call interception detection.

### Mod APK Creation Modules

*   **Mod Patcher Pro:** Inject Smali code, modify return values, toggle booleans, change integer/float values, replace strings, add/remove methods, and modify fields/constructors.
*   **Premium Unlocker:** Find VIP/Premium flags, unlock pro versions, bypass subscriptions, remove license verification, reset trial periods, disable feature gates, remove ads, and bypass in-app purchases.
*   **Game Mod Tools:** Modify currency, health, ammo, energy. Enable god mode, one-hit kill, unlock levels/characters, and inject speed/damage/defense multipliers.
*   **Permission Customizer:** Remove/add permissions, change protection levels, remove permission requests from code, bypass permission checks, and grant all permissions at install.
*   **Resource Modder:** Replace app icons, change app names, customize color themes, edit layout XML, modify string resources, replace images/fonts, and modify animations/sound effects.
*   **Manifest Modder:** Change package name, version code/name, min/target SDK, enable debuggable flag, modify backup flag, change install location, lock screen orientation, and enable/disable multi-window.
*   **Code Injector:** Inject Toast messages, add custom activities/services, broadcast receivers, Frida gadgets, Xposed modules, custom `.so` libraries, and WebView JavaScript.
*   **APK Protection Stripper:** Remove certificate/SSL pinning, bypass root/emulator/jailbreak detection, disable anti-tamper/integrity checks, and remove signature verification/VPN/proxy detection.
*   **Mod Build System:** Auto-recompile after mods, auto-sign with custom keystore, ZipAlign optimization, multi-ABI support, mod variant manager, one-click rebuild, and test install to device.
*   **Mod Templates Library:** Ready-to-use templates for premium unlock, no-ads, god mode, unlimited currency, root bypass, SSL unpin, and custom splash screens. Supports saving and loading custom templates.
*   **Mod Testing & Debugging:** Logcat filter for modded apps, crash detector, mod verification checklist, before/after comparison, feature tester, compatibility checker, and mod success rate tracker.
*   **Mod APK Reporter:** Generate mod summary reports, list applied mods, log Smali/resource/manifest changes, share mod config, export mod as patch file, and generate mod APK info cards.

## Installation

To install SHAIDAN, follow these steps in your Termux terminal:

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/yourusername/shaidan.git
    cd shaidan
    ```

2.  **Make the installer executable:**
    ```bash
    chmod +x install.sh
    ```

3.  **Run the installer:**
    ```bash
    ./install.sh
    ```

    The installer will update Termux, install core dependencies, and optionally install additional tools like `jadx` and `frida-tools`.

## Usage

After installation, you can launch SHAIDAN by typing `shaidan` in your Termux terminal:

```bash
shaidan
```

This will open the main interactive menu. You can also use direct commands:

### Reverse Engineering Commands

*   `shaidan decompile <apk>`: Decompile an APK.
*   `shaidan native <apk>`: Analyze native libraries.
*   `shaidan smali <dir>`: Browse Smali code.
*   `shaidan dex <apk>`: Perform DEX deep analysis.
*   `shaidan secrets <apk>`: Scan for secrets and patterns.
*   `shaidan manifest <apk>`: Analyze `AndroidManifest.xml`.
*   `shaidan obfus <apk>`: Detect obfuscation.
*   `shaidan malware <apk>`: Scan for malware.

### Mod APK Creation Commands

*   `shaidan mod <apk>`: Open interactive mod menu.
*   `shaidan mod-premium <apk>`: Apply premium unlock mod.
*   `shaidan mod-game <apk>`: Use game mod tools.
*   `shaidan mod-permissions <apk>`: Customize permissions.
*   `shaidan mod-resources <apk>`: Modify resources.
*   `shaidan mod-manifest <apk>`: Edit manifest.
*   `shaidan mod-inject <apk>`: Inject code/toast.
*   `shaidan mod-bypass <apk>`: Strip protections.
*   `shaidan mod-build <dir>`: Build and sign mod APK.

### Utility Commands

*   `shaidan template <name>`: Load a mod template.
*   `shaidan templates`: Browse the template library.
*   `shaidan patch <apk>`: Apply a patch file.
*   `shaidan diff <apk1> <apk2>`: Compare APKs.
*   `shaidan auto-mod <apk>`: Run full auto mod pipeline.
*   `shaidan test <apk>`: Test a modded APK.
*   `shaidan report <apk>`: Generate a mod report.
*   `shaidan help`: Display help message.
*   `shaidan about`: Display information about SHAIDAN.

## File Structure

```
shaidan/
├── install.sh
├── shaidan.sh
├── core/
│   ├── config.sh
│   ├── banner.sh
│   ├── menu.sh
│   └── utils.sh
├── modules/
│   ├── re/
│   │   ├── decompiler.sh
│   │   ├── native.sh
│   │   ├── smali.sh
│   │   ├── dex.sh
│   │   ├── secrets.sh
│   │   ├── manifest.sh
│   │   ├── obfuscation.sh
│   │   └── malware.sh
│   └── mod/
│       ├── patcher.sh
│       ├── premium.sh
│       ├── game.sh
│       ├── permissions.sh
│       ├── resources.sh
│       ├── manifest_mod.sh
│       ├── injector.sh
│       ├── protection.sh
│       ├── builder.sh
│       ├── templates.sh
│       ├── tester.sh
│       └── reporter.sh
├── deps/
│   └── check.sh
├── rules/
│   ├── yara_rules.yar  (Placeholder)
│   └── malware_sigs.db (Placeholder)
├── templates/
│   ├── premium_unlock.sh (Placeholder)
│   ├── no_ads.sh (Placeholder)
│   ├── god_mode.sh (Placeholder)
│   ├── unlimited_currency.sh (Placeholder)
│   ├── root_bypass.sh (Placeholder)
│   └── ssl_unpin.sh (Placeholder)
├── reports/
│   ├── mod_report.md (Placeholder)
│   └── reverse_report.html (Placeholder)
└── README.md
```

## Dependencies

SHAIDAN relies on several tools and utilities. The `install.sh` script will attempt to install the core dependencies automatically. Optional dependencies can be installed interactively.

### Core Dependencies (Auto-installed)

*   `apktool`, `aapt`/`aapt2`, `apksigner`, `zipalign`
*   `openjdk-17`, `python`, `nodejs`
*   `git`, `curl`, `wget`, `jq`, `xmlstarlet`
*   `binutils` (`readelf`, `objdump`, `strings`, `nm`)
*   `grep`, `sed`, `awk`, `diff`, `find`, `patch`

### Optional Dependencies (Prompted for installation)

*   `jadx`, `dex2jar`, `jd-cli`, `cfr`
*   `bundletool`, `frida-tools`
*   `nmap`, `imagemagick`, `pngquant`
*   `yara`, `binwalk`

## Creator

Dan from Malaysia 🇲🇾

## License

(To be specified)
