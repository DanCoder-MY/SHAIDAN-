#!/bin/bash

# SHAIDAN Banner

source "$(dirname "$(readlink -f "$0")")"/config.sh

function display_banner() {
    echo -e "${COLOR_GOLD}╔══════════════════════════════════════════╗${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║                                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   ⚡  S H A I D A N                      ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   APK Reverse Engineering               ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   + Mod APK Master Suite                ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║                                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   Reverse. Modify. Conquer.              ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   Reverse. Ubah. Takluk.                ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║                                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   Created by Dan                         ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   🇲🇾 Malaysia                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║                                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║   Type \'shaiden help\' for commands       ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║                                          ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}╚══════════════════════════════════════════╝${COLOR_RESET}"
    echo ""
}
