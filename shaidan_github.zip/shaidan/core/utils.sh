#!/bin/bash

# SHAIDAN Utility Functions

source "$(dirname "$(readlink -f "$0")")"/config.sh

# Function to print colored messages
print_info() {
    echo -e "${COLOR_ACCENT}[INFO] $1${COLOR_RESET}"
}

print_success() {
    echo -e "${COLOR_GOLD}[SUCCESS] $1${COLOR_RESET}"
}

print_error() {
    echo -e "${COLOR_BG}${COLOR_ACCENT}[ERROR] $1${COLOR_RESET}"
}

print_warning() {
    echo -e "${COLOR_ACCENT}[WARNING] $1${COLOR_RESET}"
}

# Function for progress bar (simplified)
function progress_bar() {
    local duration=${1}
    local progress_char="#"
    local empty_char="-"
    local bar_length=30

    for ((i=0; i<=duration; i++)); do
        local progress=$(( i * 100 / duration ))
        local filled_length=$(( bar_length * i / duration ))
        local empty_length=$(( bar_length - filled_length ))
        local bar=$(printf "%-*s" "$filled_length" "" | sed "s/ /${progress_char}/g")
        local empty=$(printf "%-*s" "$empty_length" "" | sed "s/ /${empty_char}/g")
        echo -ne "\r${COLOR_ACCENT}[${bar}${empty}] ${progress}%${COLOR_RESET}"
        sleep 0.1
    done
    echo -e "\r${COLOR_ACCENT}[${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}${progress_char}] 100%${COLOR_RESET}"
}

# Function to check if a command exists
command_exists () {
    command -v "$1" >/dev/null 2>&1
}

# Function to prompt for user input with a custom prompt
get_user_input() {
    local prompt_msg="$1"
    local input_var="$2"
    read -p "${SHAIDAN_PROMPT} ${prompt_msg}" "$input_var"
}

# Function to display a simple message box (placeholder)
display_message_box() {
    local title="$1"
    local message="$2"
    echo -e "${COLOR_GOLD}╔$(printf '═%.0s' $(seq 1 $((${#title} + 2))))╗${COLOR_RESET}"
    echo -e "${COLOR_GOLD}║ ${title} ║${COLOR_RESET}"
    echo -e "${COLOR_GOLD}╚$(printf '═%.0s' $(seq 1 $((${#title} + 2))))╝${COLOR_RESET}"
    echo -e "${COLOR_ACCENT}${message}${COLOR_RESET}"
    echo ""
}
