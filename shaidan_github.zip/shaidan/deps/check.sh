#!/bin/bash

# SHAIDAN Dependency Checker

source "$(dirname "$(dirname "$(readlink -f "$0")")")"/core/config.sh
source "$(dirname "$(dirname "$(readlink -f "$0")")")"/core/utils.sh

function check_dependencies() {
    print_info "Checking core dependencies..."
    local missing_deps=()
    for dep in "${CORE_DEPS[@]}"; do
        if ! command_exists "$dep"; then
            missing_deps+=("$dep")
        fi
    done

    if [ ${#missing_deps[@]} -eq 0 ]; then
        print_success "All core dependencies are installed."
        return 0
    else
        print_warning "Missing core dependencies: ${missing_deps[*]}"
        return 1
    fi
}

function check_optional_dependencies() {
    print_info "Checking optional dependencies..."
    local missing_optional_deps=()
    for dep in "${OPTIONAL_DEPS[@]}"; do
        if ! command_exists "$dep"; then
            missing_optional_deps+=("$dep")
        fi
    done

    if [ ${#missing_optional_deps[@]} -eq 0 ]; then
        print_success "All optional dependencies are installed."
        return 0
    else
        print_warning "Missing optional dependencies: ${missing_optional_deps[*]}"
        return 1
    fi
}

# Main execution for the module
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    check_dependencies
    check_optional_dependencies
fi
