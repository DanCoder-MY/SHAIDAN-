#!/bin/bash

# SHAIDAN Installation Script

# Source config and utils
SHAIDAN_HOME="$(dirname "$(readlink -f "$0")")"
source "$SHAIDAN_HOME/core/config.sh"
source "$SHAIDAN_HOME/core/utils.sh"

# Function to install Termux packages
install_termux_packages() {
    local packages=("$@")
    for pkg in "${packages[@]}"; do
        print_info "Installing $pkg..."
        pkg install -y "$pkg" || {
            print_error "Failed to install $pkg. Please check your internet connection or Termux setup."
            return 1
        }
    done
    return 0
}

# Main installation logic
print_info "Starting SHAIDAN installation..."

# Update and upgrade Termux
print_info "Updating and upgrading Termux packages..."
pkg update -y && pkg upgrade -y || {
    print_error "Failed to update/upgrade Termux. Exiting."
    exit 1
}

# Install core dependencies
print_info "Installing core dependencies..."
install_termux_packages "${CORE_DEPS[@]}" || exit 1

# Install optional dependencies
print_info "Checking for optional dependencies..."
read -p "${SHAIDAN_PROMPT} Do you want to install optional dependencies (jadx, frida-tools, etc.)? (y/N): " install_optional
if [[ "$install_optional" =~ ^[Yy]$ ]]; then
    install_termux_packages "${OPTIONAL_DEPS[@]}"
else
    print_info "Skipping optional dependencies installation."
fi

# Create symlink for shaidan command
print_info "Setting up 'shaidan' command..."
chmod +x "$SHAIDAN_HOME/shaidan.sh"
ln -sf "$SHAIDAN_HOME/shaidan.sh" "$PREFIX/bin/shaidan"

print_success "SHAIDAN installation complete!"
print_info "Type 'shaidan' to launch the tool."
