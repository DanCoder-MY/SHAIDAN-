#!/bin/bash

# SHAIDAN - APK Reverse Engineering + Mod Suite
# Main entry point script

SHAIDAN_HOME="$(dirname "$(readlink -f "$0")")"
source "$SHAIDAN_HOME/core/config.sh"
source "$SHAIDAN_HOME/core/utils.sh"
source "$SHAIDAN_HOME/core/banner.sh"
source "$SHAIDAN_HOME/core/menu.sh"

# Function to display help message
function display_help() {
    clear
    display_banner
    echo -e "${COLOR_GOLD}═══════════════════════════════════════════${COLOR_RESET}"
    echo -e "${COLOR_GOLD}  SHAIDAN COMMANDS                         ${COLOR_RESET}"
    echo -e "${COLOR_GOLD}═══════════════════════════════════════════${COLOR_RESET}"
    echo -e "${COLOR_ACCENT}Usage: shaidan [command] [options]${COLOR_RESET}"
    echo ""
    echo -e "${COLOR_ACCENT}【 Reverse Engineering 】${COLOR_RESET}"
    echo -e "  shaidan                            → Main dashboard"
    echo -e "  shaidan decompile <apk>            → Decompile APK"
    echo -e "  shaidan native <apk>               → Analyze .so files"
    echo -e "  shaidan smali <dir>                → Browse smali code"
    echo -e "  shaidan dex <apk>                  → DEX deep analysis"
    echo -e "  shaidan secrets <apk>              → Scan secrets/keys"
    echo -e "  shaidan manifest <apk>             → Manifest analysis"
    echo -e "  shaidan obfus <apk>                → Detect obfuscation"
    echo -e "  shaidan malware <apk>              → Scan for malware"
    echo ""
    echo -e "${COLOR_ACCENT}【 Mod APK Creation 】${COLOR_RESET}"
    echo -e "  shaidan mod <apk>                  → Interactive mod menu"
    echo -e "  shaidan mod-premium <apk>          → Premium unlock mod"
    echo -e "  shaidan mod-game <apk>             → Game mod tools"
    echo -e "  shaidan mod-ads <apk>              → Remove ads"
    echo -e "  shaidan mod-permissions <apk>      → Customize permissions"
    echo -e "  shaidan mod-resources <apk>        → Modify resources"
    echo -e "  shaidan mod-manifest <apk>         → Edit manifest"
    echo -e "  shaidan mod-inject <apk>           → Inject code/toast"
    echo -e "  shaidan mod-bypass <apk>           → Strip protections"
    echo -e "  shaidan mod-build <dir>            → Build & sign mod APK"
    echo ""
    echo -e "${COLOR_ACCENT}【 Utilities 】${COLOR_RESET}"
    echo -e "  shaidan template <name>            → Load mod template"
    echo -e "  shaidan templates                  → Browse template library"
    echo -e "  shaidan patch <apk>                → Apply patch file"
    echo -e "  shaidan diff <apk1> <apk2>         → Compare APKs"
    echo -e "  shaidan auto-mod <apk>             → Full auto mod pipeline"
    echo -e "  shaidan test <apk>                 → Test modded APK"
    echo -e "  shaidan report <apk>               → Generate mod report"
    echo -e "  shaidan help                       → Show this help message"
    echo -e "  shaidan about                      → About SHAIDAN"
    echo -e "${COLOR_GOLD}═══════════════════════════════════════════${COLOR_RESET}"
}

# Main logic
case "$1" in
    "decompile")
        source "$SHAIDAN_HOME/modules/re/decompiler.sh"
        decompile_apk "$2"
        ;;
    "native")
        source "$SHAIDAN_HOME/modules/re/native.sh"
        native_re_apk "$2"
        ;;
    "smali")
        source "$SHAIDAN_HOME/modules/re/smali.sh"
        smali_re_dir "$2"
        ;;
    "dex")
        source "$SHAIDAN_HOME/modules/re/dex.sh"
        dex_deep_analysis "$2"
        ;;
    "secrets")
        source "$SHAIDAN_HOME/modules/re/secrets.sh"
        scan_secrets "$2"
        ;;
    "manifest")
        source "$SHAIDAN_HOME/modules/re/manifest.sh"
        analyze_manifest "$2"
        ;;
    "obfus")
        source "$SHAIDAN_HOME/modules/re/obfuscation.sh"
        detect_obfuscation "$2"
        ;;
    "malware")
        source "$SHAIDAN_HOME/modules/re/malware.sh"
        scan_malware "$2"
        ;;
    "mod")
        # For now, just call the interactive menu
        display_mod_menu
        ;;
    "mod-premium")
        source "$SHAIDAN_HOME/modules/mod/premium.sh"
        premium_unlocker "$2"
        ;;
    "mod-game")
        source "$SHAIDAN_HOME/modules/mod/game.sh"
        game_mod_tools "$2"
        ;;
    "mod-permissions")
        source "$SHAIDAN_HOME/modules/mod/permissions.sh"
        customize_permissions "$2"
        ;;
    "mod-resources")
        source "$SHAIDAN_HOME/modules/mod/resources.sh"
        mod_resources "$2"
        ;;
    "mod-manifest")
        source "$SHAIDAN_HOME/modules/mod/manifest_mod.sh"
        mod_manifest "$2"
        ;;
    "mod-inject")
        source "$SHAIDAN_HOME/modules/mod/injector.sh"
        code_injector "$2"
        ;;
    "mod-bypass")
        source "$SHAIDAN_HOME/modules/mod/protection.sh"
        strip_protection "$2"
        ;;
    "mod-build")
        source "$SHAIDAN_HOME/modules/mod/builder.sh"
        mod_build_system "$2"
        ;;
    "template")
        source "$SHAIDAN_HOME/modules/mod/templates.sh"
        load_mod_template "$2"
        ;;
    "templates")
        source "$SHAIDAN_HOME/modules/mod/templates.sh"
        mod_templates_library
        ;;
    "test")
        source "$SHAIDAN_HOME/modules/mod/tester.sh"
        mod_tester "$2"
        ;;
    "report")
        source "$SHAIDAN_HOME/modules/mod/reporter.sh"
        mod_reporter "$2"
        ;;
    "help")
        display_help
        ;;
    "about")
        display_about
        ;;
    *) # Default to main menu if no arguments or invalid argument
        while true; do
            display_main_menu
        done
        ;;
esac
